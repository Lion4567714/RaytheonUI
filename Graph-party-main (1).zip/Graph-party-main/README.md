# Graph-party
Just a rough draft what we want to include in our website
